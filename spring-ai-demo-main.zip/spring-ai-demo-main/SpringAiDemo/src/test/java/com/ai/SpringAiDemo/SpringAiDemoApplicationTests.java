package com.ai.SpringAiDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAiDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
